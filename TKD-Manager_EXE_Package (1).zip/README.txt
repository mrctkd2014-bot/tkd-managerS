
TKD-Manager EXE Build Package
-----------------------------

This package is ready to build `TKD-Manager.exe` using GitHub Actions or local electron-builder.

How to use (non-developer mode, simplest):

1. Create a GitHub repository.
2. Upload this entire folder to the repo.
3. Go to GitHub → Actions → Run workflow.
4. GitHub builds TKD-Manager.exe for you automatically.
5. Download the EXE → Double-click → Application starts.

Place your FULL backend + frontend inside:
electron/app/backend/
electron/app/frontend/
before building.
